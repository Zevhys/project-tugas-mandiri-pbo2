-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2025 at 02:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pbo2_2310010455`
--

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `kode_dokter` varchar(5) NOT NULL,
  `nama_dokter` varchar(50) DEFAULT NULL,
  `spesialis` varchar(15) DEFAULT NULL,
  `jenis_kelamin` varchar(50) DEFAULT NULL,
  `nomor_telepon` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`kode_dokter`, `nama_dokter`, `spesialis`, `jenis_kelamin`, `nomor_telepon`) VALUES
('D-001', 'Dr. Budi Santoso', 'Umum', 'L', '081211112222'),
('D-002', 'Dr. Citra Lestari', 'Gigi', 'P', '081233334444'),
('D-003', 'Dr. Eka Pratiwi', 'Anak', 'P', '081255556666'),
('D-004', 'Dr. Fajar Nugroho', 'Mata', 'L', '081277778888'),
('D-005', 'Dr. Gunawan Wibowo', 'Jantung', 'L', '081277778888');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `nomor_rekam_medis` varchar(6) NOT NULL,
  `nama_lengkap` varchar(50) DEFAULT NULL,
  `tanggal_lahir` varchar(50) DEFAULT NULL,
  `jenis_kelamin` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `pekerjaan` varchar(30) DEFAULT NULL,
  `nomor_telepon` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pasien`
--

INSERT INTO `pasien` (`nomor_rekam_medis`, `nama_lengkap`, `tanggal_lahir`, `jenis_kelamin`, `alamat`, `pekerjaan`, `nomor_telepon`) VALUES
('RM-001', 'Andi Wijaya', '1990-05-15', 'L', 'Jl. Merdeka 10', 'Karyawan', '085612345678'),
('RM-002', 'Sinta Dewi', '1995-11-20', 'P', 'Jl. Sudirman 5', 'Mahasiswa', '085698765432'),
('RM-003', 'Rian Hidayat', '1985-01-30', 'L', 'Jl. Gajah Mada 22', 'Guru', '085611223344'),
('RM-004', 'Lina Marlina', '2000-07-10', 'P', 'Jl. Pahlawan 8', 'Pelajar', '085655667788'),
('RM-005', 'Bachtiar Yusuf', '1978-03-25', 'L', 'Jl. Diponegoro 15', 'Wiraswasta', '085699887766');

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `nomor_registrasi` varchar(10) NOT NULL,
  `tanggal_registrasi` varchar(50) DEFAULT NULL,
  `nomor_rekam_medis` varchar(6) DEFAULT NULL,
  `kode_dokter` varchar(5) DEFAULT NULL,
  `kode_poliklinik` varchar(5) DEFAULT NULL,
  `kode_bayar` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`nomor_registrasi`, `tanggal_registrasi`, `nomor_rekam_medis`, `kode_dokter`, `kode_poliklinik`, `kode_bayar`) VALUES
('REG-001', '2025-11-01', 'RM-001', 'D-001', 'P-001', 'BPJS'),
('REG-002', '2025-11-01', 'RM-002', 'D-002', 'P-002', 'TUNAI'),
('REG-003', '2025-11-02', 'RM-003', 'D-003', 'P-003', 'BPJS'),
('REG-004', '2025-11-03', 'RM-004', 'D-004', 'P-004', 'TUNAI'),
('REG-005', '2025-11-03', 'RM-005', 'D-005', 'P-005', 'BPJS');

-- --------------------------------------------------------

--
-- Table structure for table `poliklinik`
--

CREATE TABLE `poliklinik` (
  `kode_poliklinik` varchar(5) NOT NULL,
  `nama_poliklinik` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `poliklinik`
--

INSERT INTO `poliklinik` (`kode_poliklinik`, `nama_poliklinik`) VALUES
('P-001', 'Poli Umum'),
('P-002', 'Poli Gigi'),
('P-003', 'Poli Anak'),
('P-004', 'Poli Mata'),
('P-005', 'Poli Jantung');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`kode_dokter`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`nomor_rekam_medis`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`nomor_registrasi`);

--
-- Indexes for table `poliklinik`
--
ALTER TABLE `poliklinik`
  ADD PRIMARY KEY (`kode_poliklinik`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
