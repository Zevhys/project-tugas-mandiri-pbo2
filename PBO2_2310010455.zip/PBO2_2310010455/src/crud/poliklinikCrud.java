package crud;

import db_config.koneksi;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class poliklinikCrud {

    public String VAR_KODE_POLIKLINIK = null;
    public String VAR_NAMA_POLIKLINIK = null;
    public boolean validasi = false;

    public void simpanPoliklinik(String kodePoliklinik, String namaPoliklinik) {
        try (Connection conn = koneksi.getKoneksi()) {
            String sql
                    = "insert into poliklinik(kode_poliklinik, nama_poliklinik) value(?, ?)";
            String cekPrimary = "select * from poliklinik where kode_poliklinik = ?";

            try (PreparedStatement check = conn.prepareStatement(cekPrimary)) {
                check.setString(1, kodePoliklinik);
                ResultSet data = check.executeQuery();

                if (data.next()) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Kode Poliklinik Sudah Terdaftar"
                    );
                    this.VAR_NAMA_POLIKLINIK = data.getString("nama_poliklinik");
                    this.validasi = true;
                } else {
                    this.validasi = false;
                    this.VAR_NAMA_POLIKLINIK = null;

                    try (PreparedStatement perintah = conn.prepareStatement(sql)) {
                        perintah.setString(1, kodePoliklinik);
                        perintah.setString(2, namaPoliklinik);
                        perintah.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error SQL saat Simpan: " + e.getMessage()
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error Umum saat Simpan: " + e.getMessage()
            );
        }
    }

    public void ubahPoliklinik(String kodePoliklinik, String namaPoliklinik) {
        String sql
                = "update poliklinik set nama_poliklinik = ? where kode_poliklinik = ?";

        try (
                Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {
            perintah.setString(1, namaPoliklinik);
            perintah.setString(2, kodePoliklinik);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "Kode Poliklinik tidak ditemukan. Data GAGAL diubah."
                );
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saat Ubah: " + e.getMessage());
        }
    }

    public void hapusPoliklinik(String kodePoliklinik) {
        String sql = "delete from poliklinik where kode_poliklinik = ?";

        try (
                Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {
            perintah.setString(1, kodePoliklinik);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "Kode Poliklinik tidak ditemukan. Data GAGAL dihapus."
                );
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error saat Hapus: " + e.getMessage()
            );
        }
    }

    public void tampilDataPoliklinik(JTable komponenTable, String SQL) {
        DefaultTableModel modelTable = new DefaultTableModel();

        modelTable.addColumn("Kode Poliklinik");
        modelTable.addColumn("Nama Poliklinik");

        try (
                Connection conn = koneksi.getKoneksi(); Statement perintah = conn.createStatement(); ResultSet data = perintah.executeQuery(SQL)) {
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();

            while (data.next()) {
                Object[] row = new Object[jumKolom];
                for (int i = 1; i <= jumKolom; i++) {
                    row[i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
            }

            komponenTable.setModel(modelTable);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error SQL saat Tampil Data: " + e.getMessage()
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error Umum saat Tampil Data: " + e.getMessage()
            );
        }
    }

    public void cetakLaporan(String fileLaporan, String SQL) {
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, koneksi.getKoneksi());
            JasperViewer.viewReport(jp);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Cetak: " + e.getMessage());
        }
    }
}
