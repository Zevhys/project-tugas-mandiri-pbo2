package crud;

import db_config.koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class dokterCrud {

    public String VAR_KODE_DOKTER = null;
    public String VAR_NAMA_DOKTER = null;
    public String VAR_SPESIALIS = null;
    public String VAR_JENIS_KELAMIN = null;
    public String VAR_NOMOR_TELEPON = null;
    public boolean validasi = false;

    public void simpanDokter(String kodeDokter, String namaDokter, String spesialis, String jenisKelamin, String nomorTelepon) {

        try (Connection conn = koneksi.getKoneksi()) {
            String sql = "insert into dokter(kode_dokter, nama_dokter, spesialis, jenis_kelamin, nomor_telepon) value(?, ?, ?, ?, ?)";
            String cekPrimary = "select * from dokter where kode_dokter = ?";

            try (PreparedStatement check = conn.prepareStatement(cekPrimary)) {
                check.setString(1, kodeDokter);
                ResultSet data = check.executeQuery();

                if (data.next()) {
                    JOptionPane.showMessageDialog(null, "Kode Dokter Sudah Terdaftar");
                    this.VAR_NAMA_DOKTER = data.getString("nama_dokter");
                    this.VAR_SPESIALIS = data.getString("spesialis");
                    this.VAR_JENIS_KELAMIN = data.getString("jenis_kelamin");
                    this.VAR_NOMOR_TELEPON = data.getString("nomor_telepon");
                    this.validasi = true;
                } else {
                    this.validasi = false;
                    this.VAR_NAMA_DOKTER = null;
                    this.VAR_SPESIALIS = null;
                    this.VAR_JENIS_KELAMIN = null;
                    this.VAR_NOMOR_TELEPON = null;

                    try (PreparedStatement perintah = conn.prepareStatement(sql)) {
                        perintah.setString(1, kodeDokter);
                        perintah.setString(2, namaDokter);
                        perintah.setString(3, spesialis);
                        perintah.setString(4, jenisKelamin);
                        perintah.setString(5, nomorTelepon);
                        perintah.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error SQL saat Simpan: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Umum saat Simpan: " + e.getMessage());
        }
    }

    public void ubahDokter(String kodeDokter, String namaDokter, String spesialis, String jenisKelamin, String nomorTelepon) {
        String sql = "update dokter set nama_dokter = ?, spesialis = ?, " + "jenis_kelamin = ?, nomor_telepon = ? where kode_dokter = ?";

        try (Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {

            perintah.setString(1, namaDokter);
            perintah.setString(2, spesialis);
            perintah.setString(3, jenisKelamin);
            perintah.setString(4, nomorTelepon);
            perintah.setString(5, kodeDokter);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
            } else {
                JOptionPane.showMessageDialog(null, "Kode Dokter tidak ditemukan. Data GAGAL diubah.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saat Ubah: " + e.getMessage());
        }
    }

    public void hapusDokter(String kodeDokter) {
        String sql = "delete from dokter where kode_dokter = ?";

        try (Connection conn = koneksi.getKoneksi(); PreparedStatement perintah = conn.prepareStatement(sql)) {

            perintah.setString(1, kodeDokter);

            int rowsAffected = perintah.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
            } else {
                JOptionPane.showMessageDialog(null, "Kode Dokter tidak ditemukan. Data GAGAL dihapus.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saat Hapus: " + e.getMessage());
        }
    }

    public void tampilDataDokter(JTable komponenTable, String SQL) {
        DefaultTableModel modelTable = new DefaultTableModel();

        modelTable.addColumn("Kode Dokter");
        modelTable.addColumn("Nama Dokter");
        modelTable.addColumn("Spesialis");
        modelTable.addColumn("Jenis Kelamin");
        modelTable.addColumn("Nomor Telepon");

        try (Connection conn = koneksi.getKoneksi(); Statement perintah = conn.createStatement(); ResultSet data = perintah.executeQuery(SQL)) {

            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();

            while (data.next()) {
                Object[] row = new Object[jumKolom];
                for (int i = 1; i <= jumKolom; i++) {
                    row[i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
            }

            komponenTable.setModel(modelTable);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error SQL saat Tampil Data: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Umum saat Tampil Data: " + e.getMessage());
        }
    }

    public void cetakLaporan(String fileLaporan, String SQL) {
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, koneksi.getKoneksi());
            JasperViewer.viewReport(jp);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Cetak: " + e.getMessage());
        }
    }

}
