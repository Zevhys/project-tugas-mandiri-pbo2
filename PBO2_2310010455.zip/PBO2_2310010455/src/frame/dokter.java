package frame;

import crud.dokterCrud;
import javax.swing.JOptionPane;

public class dokter extends javax.swing.JFrame {

    private dokterCrud objek;

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(dokter.class.getName());

    public dokter() {
        initComponents();
        this.setLocationRelativeTo(null);
        objek = new dokterCrud();
        objek.tampilDataDokter(tableDokter, "select * from dokter");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtKodeDokter = new javax.swing.JTextField();
        txtNamaDokter = new javax.swing.JTextField();
        txtJenisKelamin = new javax.swing.JTextField();
        txtSpesialis = new javax.swing.JTextField();
        txtNomorTelepon = new javax.swing.JTextField();
        btnUbah = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableDokter = new javax.swing.JTable();
        txtCari = new javax.swing.JTextField();
        btnCetak = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Frame Dokter");

        jLabel1.setText("Kode Dokter");

        jLabel2.setText("Nama Dokter");

        jLabel3.setText("Spesialis");

        jLabel4.setText("Jenis Kelamin");

        jLabel5.setText("No Telepon");

        btnUbah.setText("Ubah");
        btnUbah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUbahActionPerformed(evt);
            }
        });

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        jLabel6.setText("Cari Data Berdasarkan Nama Dokter");

        tableDokter.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tableDokter);

        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        btnCetak.setText("Cetak");
        btnCetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCetakActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(194, 194, 194)
                        .addComponent(txtNomorTelepon, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(191, 191, 191)
                        .addComponent(txtKodeDokter, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(186, 186, 186)
                        .addComponent(txtNamaDokter, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnTambah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUbah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnHapus)
                        .addGap(9, 9, 9)
                        .addComponent(btnCetak))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(212, 212, 212)
                        .addComponent(txtSpesialis, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(73, 73, 73)
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(185, 185, 185)
                        .addComponent(txtJenisKelamin, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(60, 60, 60))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtKodeDokter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtNamaDokter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtSpesialis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtJenisKelamin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(txtNomorTelepon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambah)
                    .addComponent(btnUbah)
                    .addComponent(btnHapus)
                    .addComponent(btnCetak))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        try {
            if (txtKodeDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Dokter Belum Diisi");
                txtKodeDokter.requestFocus();
            } else if (txtNamaDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nama Dokter Belum Diisi");
            } else if (txtSpesialis.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Spesialis Belum Diisi");
            } else if (txtJenisKelamin.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Jenis Kelamin Belum Diisi");
            } else if (txtNomorTelepon.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Telepon Belum Diisi");
            } else {
                objek.simpanDokter(txtKodeDokter.getText(), txtNamaDokter.getText(), txtSpesialis.getText(), txtJenisKelamin.getText(), txtNomorTelepon.getText());
                objek.tampilDataDokter(tableDokter, "select * from dokter");
                if (objek.validasi == true) {
                    txtNamaDokter.setText(objek.VAR_NAMA_DOKTER);
                    txtSpesialis.setText(objek.VAR_SPESIALIS);
                    txtJenisKelamin.setText(objek.VAR_JENIS_KELAMIN);
                    txtNomorTelepon.setText(objek.VAR_NOMOR_TELEPON);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUbahActionPerformed
        try {
            if (txtKodeDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Dokter Belum Diisi");
                txtKodeDokter.requestFocus();
            } else if (txtNamaDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nama Dokter Belum Diisi");
            } else if (txtSpesialis.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Spesialis Medis Belum Diisi");
            } else if (txtJenisKelamin.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Jenis Kelamin Belum Diisi");
            } else if (txtNomorTelepon.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Telepon Belum Diisi");
            } else {
                objek.ubahDokter(txtKodeDokter.getText(), txtNamaDokter.getText(), txtSpesialis.getText(), txtJenisKelamin.getText(), txtNomorTelepon.getText());
                if (objek.validasi == true) {
                    txtKodeDokter.setText(objek.VAR_KODE_DOKTER);
                    txtNamaDokter.setText(objek.VAR_NAMA_DOKTER);
                    txtKodeDokter.setText(objek.VAR_KODE_DOKTER);
                    txtSpesialis.setText(objek.VAR_SPESIALIS);
                    txtJenisKelamin.setText(objek.VAR_JENIS_KELAMIN);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnUbahActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        try {
            objek.hapusDokter(txtKodeDokter.getText());
            txtKodeDokter.setText(null);
            txtNamaDokter.setText(null);
            txtSpesialis.setText(null);
            txtJenisKelamin.setText(null);
            txtNomorTelepon.setText(null);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        String cari = "select * from dokter where nama_dokter like '%" + txtCari.getText() + "%'";
        objek.tampilDataDokter(tableDokter, cari);
    }//GEN-LAST:event_txtCariKeyReleased

    private void btnCetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCetakActionPerformed
        objek.cetakLaporan("src/laporan/laporanDokter.jrxml", "SELECT * FROM dokter");
    }//GEN-LAST:event_btnCetakActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new dokter().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCetak;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnUbah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tableDokter;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtJenisKelamin;
    private javax.swing.JTextField txtKodeDokter;
    private javax.swing.JTextField txtNamaDokter;
    private javax.swing.JTextField txtNomorTelepon;
    private javax.swing.JTextField txtSpesialis;
    // End of variables declaration//GEN-END:variables
}
