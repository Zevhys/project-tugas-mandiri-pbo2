package frame;

import crud.pendaftaranCrud;
import javax.swing.JOptionPane;

public class pendaftaran extends javax.swing.JFrame {

    private pendaftaranCrud objek;

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(pendaftaran.class.getName());

    public pendaftaran() {
        initComponents();
        this.setLocationRelativeTo(null);
        objek = new pendaftaranCrud();
        objek.tampilDataPendaftaran(tablePendaftaran, "select * from pendaftaran");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtTanggalRegistrasi = new javax.swing.JTextField();
        txtNomorRekamMedis = new javax.swing.JTextField();
        txtKodeDokter = new javax.swing.JTextField();
        txtKodePoliklinik = new javax.swing.JTextField();
        txtKodeBayar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNomorRegistrasi = new javax.swing.JTextField();
        btnUbah = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        txtCari = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablePendaftaran = new javax.swing.JTable();
        btnCetak = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Frame Pendaftaran");

        txtTanggalRegistrasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTanggalRegistrasiActionPerformed(evt);
            }
        });

        txtNomorRekamMedis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomorRekamMedisActionPerformed(evt);
            }
        });

        txtKodePoliklinik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKodePoliklinikActionPerformed(evt);
            }
        });

        jLabel1.setText("Nomor Registrasi");

        jLabel2.setText("Tanggal Registrasi");

        jLabel3.setText("Nomor Rekam Medis");

        jLabel4.setText("Kode Dokter");

        jLabel5.setText("Kode Poliklinik");

        jLabel6.setText("Kode Bayar");

        btnUbah.setText("Ubah");
        btnUbah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUbahActionPerformed(evt);
            }
        });

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        txtCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCariKeyReleased(evt);
            }
        });

        jLabel7.setText("Cari Data Berdasarkan Nomor Registrasi");

        tablePendaftaran.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablePendaftaran);

        btnCetak.setText("Cetak");
        btnCetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCetakActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(252, 252, 252)
                .addComponent(btnTambah)
                .addGap(18, 18, 18)
                .addComponent(btnUbah)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHapus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCetak)
                .addContainerGap(196, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(15, 15, 15)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNomorRegistrasi, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTanggalRegistrasi, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNomorRekamMedis, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtKodeDokter, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtKodePoliklinik, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtKodeBayar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 441, Short.MAX_VALUE)
                            .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(15, 15, 15)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(345, 345, 345)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambah)
                    .addComponent(btnUbah)
                    .addComponent(btnHapus)
                    .addComponent(btnCetak))
                .addGap(45, 45, 45)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(105, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(36, 36, 36)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel1)
                        .addComponent(txtNomorRegistrasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2)
                        .addComponent(txtTanggalRegistrasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(20, 20, 20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3)
                        .addComponent(txtNomorRekamMedis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(20, 20, 20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4)
                        .addComponent(txtKodeDokter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(20, 20, 20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5)
                        .addComponent(txtKodePoliklinik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(txtKodeBayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel7)
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(616, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtTanggalRegistrasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTanggalRegistrasiActionPerformed
    }//GEN-LAST:event_txtTanggalRegistrasiActionPerformed

    private void txtNomorRekamMedisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomorRekamMedisActionPerformed
    }//GEN-LAST:event_txtNomorRekamMedisActionPerformed

    private void txtKodePoliklinikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKodePoliklinikActionPerformed
    }//GEN-LAST:event_txtKodePoliklinikActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        try {
            if (txtNomorRegistrasi.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Registrasi Belum Diisi");
                txtNomorRegistrasi.requestFocus();
            } else if (txtTanggalRegistrasi.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tangal Registrasi Belum Diisi");
            } else if (txtNomorRekamMedis.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Rekam Medis Belum Diisi");
            } else if (txtKodeDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Dokter Belum Diisi");
            } else if (txtKodePoliklinik.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Poliklinik Belum Diisi");
            } else if (txtKodeBayar.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Bayar Belum Diisi");
            } else {
                objek.simpanPendaftaran(txtNomorRegistrasi.getText(), txtTanggalRegistrasi.getText(), txtNomorRekamMedis.getText(), txtKodeDokter.getText(), txtKodePoliklinik.getText(), txtKodeBayar.getText());
                objek.tampilDataPendaftaran(tablePendaftaran, "select * from pendaftaran");
                if (objek.validasi == true) {
                    txtTanggalRegistrasi.setText(objek.VAR_TANGGAL_REGISTRASI);
                    txtNomorRekamMedis.setText(objek.VAR_NOMOR_REKAM_MEDIS);
                    txtKodeDokter.setText(objek.VAR_KODE_DOKTER);
                    txtKodePoliklinik.setText(objek.VAR_KODE_POLIKLINIK);
                    txtKodeBayar.setText(objek.VAR_KODE_BAYAR);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUbahActionPerformed
        try {
            if (txtNomorRegistrasi.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Registrasi Belum Diisi");
                txtNomorRegistrasi.requestFocus();
            } else if (txtTanggalRegistrasi.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Tanggal Registrasi Belum Diisi");
            } else if (txtNomorRekamMedis.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Nomor Rekam Medis Belum Diisi");
            } else if (txtKodeDokter.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Dokter Belum Diisi");
            } else if (txtKodePoliklinik.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Klinik Belum Diisi");
            } else if (txtKodeBayar.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Kode Bayar Belum Diisi");
            } else {
                objek.ubahPendaftaran(
                        txtNomorRegistrasi.getText(),
                        txtTanggalRegistrasi.getText(),
                        txtNomorRekamMedis.getText(),
                        txtKodeDokter.getText(),
                        txtKodePoliklinik.getText(),
                        txtKodeBayar.getText()
                );
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mengubah data: " + e.getMessage());
        }
    }//GEN-LAST:event_btnUbahActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        try {
            objek.hapusPendaftaran(txtNomorRegistrasi.getText());
            txtNomorRegistrasi.setText(null);
            txtTanggalRegistrasi.setText(null);
            txtNomorRekamMedis.setText(null);
            txtKodeDokter.setText(null);
            txtKodePoliklinik.setText(null);
            txtKodeBayar.setText(null);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void txtCariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCariKeyReleased
        String cari = "select * from pendaftaran where nomor_registrasi like '%" + txtCari.getText() + "%'";
        objek.tampilDataPendaftaran(tablePendaftaran, cari);
    }//GEN-LAST:event_txtCariKeyReleased

    private void btnCetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCetakActionPerformed
        objek.cetakLaporan("src/laporan/laporanPendaftaran.jrxml", "SELECT * FROM pendaftaran");
    }//GEN-LAST:event_btnCetakActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new pendaftaran().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCetak;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnUbah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablePendaftaran;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtKodeBayar;
    private javax.swing.JTextField txtKodeDokter;
    private javax.swing.JTextField txtKodePoliklinik;
    private javax.swing.JTextField txtNomorRegistrasi;
    private javax.swing.JTextField txtNomorRekamMedis;
    private javax.swing.JTextField txtTanggalRegistrasi;
    // End of variables declaration//GEN-END:variables
}
